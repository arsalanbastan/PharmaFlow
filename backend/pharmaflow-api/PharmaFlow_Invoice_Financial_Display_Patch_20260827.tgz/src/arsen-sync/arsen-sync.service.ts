import { BadRequestException, Injectable } from '@nestjs/common';
import { createHash } from 'node:crypto';

import { AuditLogService } from '../audit/audit-log.service';
import { PrismaService } from '../database/prisma/prisma.service';
import { ArsenInvoiceDto } from './dto/arsen-invoice.dto';

function canonicalize(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value.map((item) => canonicalize(item));
  }

  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([key, item]) => [key, canonicalize(item)]),
    );
  }

  return value;
}

function fingerprint(value: unknown): string {
  return createHash('sha256')
    .update(JSON.stringify(canonicalize(value)))
    .digest('hex');
}

function nullableText(value: string | null | undefined): string | null {
  const text = String(value ?? '').trim();
  return text || null;
}

function nullableDate(value: string | null | undefined): Date | null {
  return value ? new Date(value) : null;
}

@Injectable()
export class ArsenSyncService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly auditLog: AuditLogService,
  ) {}

  async status() {
    const [mappingCount, invoiceCount, latestInvoice] = await Promise.all([
      this.prisma.arsenCompanyMapping.count(),
      this.prisma.arsenInvoice.count(),
      this.prisma.arsenInvoice.findFirst({
        orderBy: { ingestSequence: 'desc' },
        select: {
          arsenFactorId: true,
          invoiceNumber: true,
          invoiceDate: true,
          sourceSyncedAt: true,
        },
      }),
    ]);

    return {
      status: 'ok',
      mappingCount,
      invoiceCount,
      latestInvoice,
    };
  }

  async ingest(invoices: ArsenInvoiceDto[]) {
    const results: Array<{
      arsenFactorId: number;
      status: 'CREATED' | 'UPDATED' | 'UNCHANGED';
      invoiceId: string;
    }> = [];

    for (const invoice of invoices) {
      results.push(await this.ingestOne(invoice));
    }

    return {
      processed: results.length,
      created: results.filter((item) => item.status === 'CREATED').length,
      updated: results.filter((item) => item.status === 'UPDATED').length,
      unchanged: results.filter((item) => item.status === 'UNCHANGED').length,
      results,
    };
  }

  private async ingestOne(invoice: ArsenInvoiceDto) {
    const detailIds = invoice.items.map((item) => item.arsenFactorDetailId);

    if (new Set(detailIds).size !== detailIds.length) {
      throw new BadRequestException(
        `Arsen factor ${invoice.arsenFactorId} contains duplicate detail IDs.`,
      );
    }

    const mapping = await this.prisma.arsenCompanyMapping.findUnique({
      where: { arsenBusinessPartnerId: invoice.arsenBusinessPartnerId },
      select: {
        companyId: true,
        company: { select: { deletedAt: true } },
      },
    });

    if (!mapping || mapping.company.deletedAt) {
      throw new BadRequestException(
        `Arsen BusinessPartnerID ${invoice.arsenBusinessPartnerId} is not mapped to an active PharmaFlow company.`,
      );
    }

    const sourceFingerprint = fingerprint(invoice);
    const before = await this.prisma.arsenInvoice.findUnique({
      where: { arsenFactorId: invoice.arsenFactorId },
      select: {
        id: true,
        companyId: true,
        sourceFingerprint: true,
        invoiceNumber: true,
        invoiceDate: true,
        settlementDate: true,
        description: true,
        factorPayablePrice: true,
        itemCount: true,
        isDeletedInArsen: true,
      },
    });

    if (
      before &&
      before.companyId === mapping.companyId &&
      before.sourceFingerprint === sourceFingerprint
    ) {
      return {
        arsenFactorId: invoice.arsenFactorId,
        status: 'UNCHANGED' as const,
        invoiceId: before.id,
      };
    }

    const saved = await this.prisma.$transaction(async (tx) => {
      const headerData = {
        invoiceNumber: nullableText(invoice.invoiceNumber),
        invoiceDate: nullableText(invoice.invoiceDate),
        docDate: nullableText(invoice.docDate),
        settlementDate: nullableText(invoice.settlementDate),
        description: nullableText(invoice.description),
        factorDocType: invoice.factorDocType,
        factorDocTypeName: nullableText(invoice.factorDocTypeName),
        factorType: invoice.factorType ?? null,
        factorTypeName: nullableText(invoice.factorTypeName),
        factorItemType: nullableText(invoice.factorItemType),
        arsenBusinessPartnerId: invoice.arsenBusinessPartnerId,
        arsenBusinessPartnerName: invoice.arsenBusinessPartnerName.trim(),
        companyId: mapping.companyId,
        factorTotalPrice: invoice.factorTotalPrice ?? null,
        factorDiscount: invoice.factorDiscount ?? null,
        factorTax: invoice.factorTax ?? null,
        factorPayablePrice: invoice.factorPayablePrice ?? null,
        barbariPrice: invoice.barbariPrice ?? null,
        paymentDays: invoice.paymentDays ?? null,
        isDeletedInArsen: invoice.isDeletedInArsen,
        isLockedInArsen: invoice.isLockedInArsen ?? null,
        arsenSaveDateTime: nullableDate(invoice.arsenSaveDateTime),
        itemCount: invoice.items.length,
        sourceFingerprint,
        sourceSyncedAt: new Date(),
      };

      const savedInvoice = await tx.arsenInvoice.upsert({
        where: { arsenFactorId: invoice.arsenFactorId },
        create: {
          arsenFactorId: invoice.arsenFactorId,
          ...headerData,
        },
        update: headerData,
        select: { id: true },
      });

      // A deleted source invoice may arrive without detail rows. Keep the last
      // known details so financial history remains inspectable.
      if (!invoice.isDeletedInArsen || invoice.items.length > 0) {
        await tx.arsenInvoiceItem.deleteMany({
          where: { invoiceId: savedInvoice.id },
        });

        if (invoice.items.length > 0) {
          await tx.arsenInvoiceItem.createMany({
            data: invoice.items.map((item) => ({
              invoiceId: savedInvoice.id,
              arsenFactorDetailId: BigInt(item.arsenFactorDetailId),
              arsenFactorDetailsId: item.arsenFactorDetailsId ?? null,
              arsenDrugId: item.arsenDrugId ? BigInt(item.arsenDrugId) : null,
              drugName: nullableText(item.drugName),
              barcode: nullableText(item.barcode),
              packetQuantity: item.packetQuantity ?? null,
              quantity: item.quantity ?? null,
              salePrice: item.salePrice ?? null,
              purchasePrice: item.purchasePrice ?? null,
              rowDiscount: item.rowDiscount ?? null,
              hasTax: item.hasTax ?? null,
              expireDate: nullableText(item.expireDate),
              expireDateGregorian: nullableDate(item.expireDateGregorian),
              batchNumber: nullableText(item.batchNumber),
            })),
          });
        }
      }

      await this.auditLog.record(
        {
          action: before ? 'ARSEN_INVOICE_SYNC_UPDATE' : 'ARSEN_INVOICE_SYNC_CREATE',
          entityType: 'ARSEN_INVOICE',
          entityId: savedInvoice.id,
          before,
          after: {
            arsenFactorId: invoice.arsenFactorId,
            companyId: mapping.companyId,
            invoiceNumber: invoice.invoiceNumber ?? null,
            invoiceDate: invoice.invoiceDate ?? null,
            settlementDate: invoice.settlementDate ?? null,
            description: invoice.description ?? null,
            factorDocType: invoice.factorDocType,
            factorPayablePrice: invoice.factorPayablePrice ?? null,
            itemCount: invoice.items.length,
            isDeletedInArsen: invoice.isDeletedInArsen,
            sourceFingerprint,
          },
        },
        tx,
      );

      return savedInvoice;
    });

    return {
      arsenFactorId: invoice.arsenFactorId,
      status: before ? ('UPDATED' as const) : ('CREATED' as const),
      invoiceId: saved.id,
    };
  }
}
