import {
  ADMIN_DASHBOARD_RELEASE,
  hardDeleteForm,
  layout,
} from './admin-view';

describe('full admin dashboard view', () => {
  it('exposes the exact release marker and every manager section', () => {
    const html = layout('test', '<main>ok</main>', 'dashboard');

    expect(ADMIN_DASHBOARD_RELEASE).toBe(
      'manager-web-invoices-v2-20260827',
    );
    expect(html).toContain('/admin/invoices');
    expect(html).toContain('/admin/companies');
    expect(html).toContain('/admin/bank-accounts');
    expect(html).toContain('/admin/cheques');
    expect(html).toContain('/admin/cash-payments');
    expect(html).toContain('/admin/users');
    expect(html).toContain('/admin/orders');
    expect(html).toContain('/admin/audit-logs');
  });

  it('requires an explicit DELETE confirmation for hard deletion', () => {
    const html = layout(
      'test',
      hardDeleteForm(
        '/admin/orders/id/hard-delete',
        'csrf-token',
        'test item',
      ),
      'orders',
    );

    expect(html).toContain('name="_confirmation"');
    expect(html).toMatch(/answer\s*!==\s*'DELETE'/);
    expect(html).toContain('حذف دائمی');
  });

  it('disables blocked destructive operations', () => {
    const html = hardDeleteForm(
      '/admin/companies/id/hard-delete',
      'csrf-token',
      'company',
      'has dependencies',
    );

    expect(html).toContain('disabled');
    expect(html).toContain('has dependencies');
  });
});
